package com.example.v1;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MainActivity9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);

        ImageButton bt_start = (ImageButton) findViewById(R.id.imageButton2);
        ImageButton bt_stop = (ImageButton) findViewById(R.id.imageButton3);
        MediaPlayer ring1= MediaPlayer.create(MainActivity9.this,R.raw.meditation_voice);

        bt_start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ring1.start();
            }
        });

        bt_stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ring1.pause();
            }
        });
    }
}